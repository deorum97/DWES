#Aquí tu archivo sql que contine la información de tu base de datos
#En este directorio bambién puedes incluir un script de creación de tu bbdd y/o tablas si detectas 
# que tienes acceso al servidor de bbdd pero tu estructura de datos no está montada en el servidor.
