<?php

	class mascota {
		public function __construct($nombre, $tipo, ){

		}
	}